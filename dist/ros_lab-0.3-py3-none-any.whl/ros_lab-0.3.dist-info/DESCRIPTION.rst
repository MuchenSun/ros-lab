A Docker-based virtual lab of Robot Operating System to help beginners learn and practise. It's based on docker image "muchensun/ros_turtlebot3_vnc", which is based on docker image "dorowu/ubuntu-desktop-lxde-vnc", and wrapped by a read-eval-print loop(REPL) interface implemented with Python.


